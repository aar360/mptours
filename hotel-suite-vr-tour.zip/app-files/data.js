var APP_DATA = {
  "scenes": [
    {
      "id": "0-hotel-vr-tour-01",
      "name": "Hotel VR Tour 01",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 0.04609892303957963,
        "pitch": 0,
        "fov": 1.3845933826976107
      },
      "linkHotspots": [
        {
          "yaw": -0.01771373511921226,
          "pitch": 0.12829358553283043,
          "rotation": 6.283185307179586,
          "target": "1-hotel-vr-tour-02"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-hotel-vr-tour-02",
      "name": "Hotel VR Tour 02",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.9869838279484204,
          "pitch": 0.10506245154962102,
          "rotation": 0,
          "target": "0-hotel-vr-tour-01"
        },
        {
          "yaw": 0.03635328625420975,
          "pitch": 0.14073475382736333,
          "rotation": 0,
          "target": "2-hotel-vr-tour-03"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -1.5024520696151864,
          "pitch": 0.7498931306024801,
          "title": "Dishwasher",
          "text": "Every suite is equipped with a modern dishwasher."
        }
      ]
    },
    {
      "id": "2-hotel-vr-tour-03",
      "name": "Hotel VR Tour 03",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 3.1179553301105507,
          "pitch": 0.1480118297782429,
          "rotation": 0,
          "target": "1-hotel-vr-tour-02"
        },
        {
          "yaw": 0.02061678747955753,
          "pitch": 0.08812219086128437,
          "rotation": 0,
          "target": "3-hotel-vr-tour-04"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-hotel-vr-tour-04",
      "name": "Hotel VR Tour 04",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -3.10677925046431,
          "pitch": 0.1607828183743738,
          "rotation": 0,
          "target": "2-hotel-vr-tour-03"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-hotel-vr-tour-05",
      "name": "Hotel VR Tour 05",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.4570261899551635,
          "pitch": 0.1789564282177203,
          "rotation": 0,
          "target": "3-hotel-vr-tour-04"
        },
        {
          "yaw": -0.07000732018839528,
          "pitch": 0.191623049033101,
          "rotation": 0,
          "target": "5-hotel-vr-tour-06"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "5-hotel-vr-tour-06",
      "name": "Hotel VR Tour 06",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.8055466458503293,
          "pitch": 0.1450315181009909,
          "rotation": 0,
          "target": "4-hotel-vr-tour-05"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Hotel Suite VR Tour",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
